import java.util.*;
public class MainClass {

	public static void main(String[] args) {
		int x=0,y=0;
		ArrayList<Vehicle> Parking = new ArrayList<Vehicle>();
		
		for (int i=1;i<11;i++){
			x=x+1;
			y=y+1;
			Car car = new Car(i,x,y);
			Parking.add(car);
						
		}
		for (int p=0;p<10;p++){
			System.out.print(Parking.get(p).getNumber()+ "-");
			System.out.print(Parking.get(p).getX()+ "-");
			System.out.println(Parking.get(p).getY());
		}
	
		System.out.println("Enter number for the car you want to load and load<1000kg.");
		Scanner scan = new Scanner(System.in);
		int car = scan.nextInt();
		int l = scan.nextInt();
		for (int z=0;z<10;z++){
			if( Parking.get(z).getNumber() == car  ){	
				Parking.get(z).setLoad(l);
				System.out.println("You have loaded your car.");
			}
		}
		System.out.println("Please enter car number and the coordinates (x y) that you what to move it to. ");
		int c = scan.nextInt();
		int c1 = scan.nextInt();
		int c2 = scan.nextInt();
		
		for (int z=0;z<10;z++){
			if( Parking.get(z).getNumber() == c  ){	
				Parking.get(z).Move(c1, c2);
				System.out.println("You have moved your car I will now print the new order:");
			}
		}
		
		for (int p=0;p<10;p++){
			System.out.print(Parking.get(p).getNumber()+ "-");
			System.out.print(Parking.get(p).getX()+ "-");
			System.out.print(Parking.get(p).getY()+ "-");
			System.out.println(Parking.get(p).getLoad());
		
		}
	}

}
