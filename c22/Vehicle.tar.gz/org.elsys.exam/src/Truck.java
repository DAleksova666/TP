
public class Truck extends Vehicle implements Loadable{
	private int tload;
	public Truck(int number, int x, int y) {
		super(number, x, y);
	}
	public int getLoad() {
		tload = getLoad();
	 return this.tload;
	}
	public void setLoad(int nload) {
		if ((this.tload+nload) < 20000) {
			this.tload = this.tload +nload;
		}else{
			System.out.println("Too much!You can't go over 1000kg.You currently have:"+ tload);
			
		}
	}

}
