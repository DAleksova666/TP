
public class Vehicle implements Loadable{
 private int x,y;
 private int number,load =0;
 
 public int getX() {
	return x;
 } 
 
 public void setX(int x) {
	this.x = x;
 }
 
 public int getY() {
	return y;
 }
 
 public void setY(int y) {
	this.y = y;
 }
 
 public int getNumber() {
	return number;
 }
 
 public void setNumber(int number) {
	this.number = number;
 }
 
 public Vehicle(int number,int x,int y) {
	this.number= number;
	setNumber(number);
	this.x= x;
	setX(x);
	this.y= y;
	setY(y);
	
}
 
 public void Move(int x,int y){
	this.x=x;
	this.y=y;
	setX(x);
	setY(y); 
 }

 public int getLoad() {
		return this.load;
	}
	public void setLoad(int vload) {
		this.load += vload;		
	}


}
