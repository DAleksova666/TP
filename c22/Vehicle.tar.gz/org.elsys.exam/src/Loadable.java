
public interface Loadable {
	public int getLoad();
	public void setLoad(int val);
	

}
