
public class Car extends Vehicle implements Loadable {
	private int cload = 0 ;
	public Car(int number, int x, int y) {
		super(number, x, y);
		
	}
	public int getLoad() {
	 return this.cload;
	}
	public void setLoad(int nload) {
		if ((this.cload+nload) < 1000) {
			this.cload = this.cload +nload;
		}else{
			System.out.println("Too much!You can't go over 1000kg.You currently have:"+ cload);
			
		}
	}


}
