package org.elsys.swt.draw;
public class DrawingPoint {

	public DrawingPoint(int x2, int y2) {
		this.x = x2;
		this.y = y2;
	}

	public int x;

	public int y;

	public String title;

}
