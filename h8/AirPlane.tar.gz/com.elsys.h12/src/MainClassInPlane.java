
public class MainClassInPlane {
	public static void main(String []args){
	AirPlane plane = new AirPlane();
	
	System.out.println("Capacity:"+plane.getCapacity());
	plane.fillPlane();
	System.out.println("Capacity:"+plane.getCapacity());
	System.out.print("Number of Males on the plane : ");
	System.out.println(plane.getMales());
	System.out.print("Number of Females on the plane : ");
	System.out.println(plane.getFemales());
	plane.clear();
	System.out.println("Capacity:"+plane.getCapacity());
	
	
	}
}
