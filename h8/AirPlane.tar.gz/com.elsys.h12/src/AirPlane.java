
public class AirPlane {

	private Human [][] seats= new Human [6][27];
	private int sum = 0;
	private boolean taken = false;
	private int nump = 0;
	private int males , females;
	private int cap=0;
	
	

	 public void printSeats() {
		for (int i=0; i<27; i++) {
			for(int k=0; k<6; k++) {
				if(k == 2){
					System.out.print(seats[k][i] + " ");
				} else {
					System.out.print(seats[k][i] );
				}
			}
			System.out.println();
		}
	 }

	 public void add(int nump , Human a, Human b, Human c ){
			taken = false;
			for(int i = 0; i<27; i++) {
				for(int k = 0; k<6; k++) {
					if(seats[k][i] == null) {
						switch (nump){
						case 1:
								seats[k][i] = a;
								sum += nump;
								taken = true;
							break;
						case 2:
							if(k<=4) {
								if(seats[k+1][i] == null && k!=2 && k!=5) {
									seats[k][i] = b;								
									seats[k+1][i] = c;
									sum += nump;
									taken = true;
								break;
								}
							}
							break;

						case 3:
							if(k<=3) {
								if(seats[k+1][i] == null && seats[k+2][i] == null && (k==0 || k==3)){
									
								seats[k][i] = a;
								seats[k+1][i] = b;
								seats[k+2][i] = c;
								sum += nump;
								taken = true;
								break;
								}
							}
						break;
						default: break;
						}
					}else {
					continue;
					}
				}	
				if(taken == true) {
					break;
				}
			}
				if(taken == false){
				System.out.println("Please wait for another plane.We don't have free seats for you.");
				}
	 }
	public int getCapacity(){
	cap = 162 - sum;
			return cap;
	}
	public int getMales(){
			return males;
	}
		
	public int getFemales(){
			return females;
	}
	
	public void clear(){
		for(int i = 0; i<27; i++){
			for(int k = 0;k < 6; k++){
				seats[k][i] = null;
			}
		}
	}


	public int freeSeats() {
			int freeseats;
			if(sum < 162) {
				freeseats = 162 - sum;
				return freeseats;
			} else {
				System.out.println("There are no free seats left.");
				return 0;
			}
	}

	public void fillPlane(){
		 AirPlane plane = new AirPlane();
		 while(plane.freeSeats() != 0){
			 nump = (int)((Math.random() * 10)%3)+1;
			 switch (nump){
			 case 1:
				 	Human a= new Human();
					a.setName("1");
					a.createGender();
					if (a.getGender() == "Male"){
						males+=1;
					}
					if (a.getGender() == "Female"){
						females+=1;
					}
					
					plane.add(nump, a, null , null);
				break;
			 case 2:
					
					Human b = new Human();
					b.setName("2");
					b.createGender();
					
					if (b.getGender() == "Male"){
						males+=1;
					}
					if (b.getGender() == "Female"){
						females+=1;
					}
					Human c = new Human();
					c.setName("2");
					c.createGender();
					if (c.getGender() == "Male"){
						males+=1;
					}
					if (c.getGender() == "Female"){
						females+=1;
					}
					plane.add(nump, b, c , null);
				break;	
			 case 3:
				 	Human d = new Human();
					d.setName("3");
					d.createGender();
					if (d.getGender() == "Male"){
						males+=1;
					}
					if (d.getGender() == "Female"){
						females+=1;
					}
					Human e = new Human();
					e.setName("3");
					e.createGender();
					if (e.getGender() == "Male"){
						males+=1;
					}
					if (e.getGender() == "Female"){
						females+=1;
					}
					Human f= new Human();
					f.setName("3");
					f.createGender();
					if (f.getGender() == "Male"){
						males+=1;
					}
					if (f.getGender() == "Female"){
						females+=1;
					}
					plane.add(nump, d , e , f);
					
				break;
					
				 
			 }
		}
	 }
	
}
