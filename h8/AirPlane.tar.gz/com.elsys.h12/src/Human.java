
public class Human {


	private String name;
	private String gender;
	private int rand;

	public void createGender(){
		rand = (int)((Math.random() * 10)%2)+1;
		if (rand==1){
			gender = "Male";
			setGender(gender);
		}
		else{
			gender = "Female";
			setGender(gender);
		}
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		
		this.gender = gender;
	}
}
