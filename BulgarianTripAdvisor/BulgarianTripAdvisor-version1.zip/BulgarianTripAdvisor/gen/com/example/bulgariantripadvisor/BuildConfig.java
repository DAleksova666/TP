/** Automatically generated file. DO NOT MODIFY */
package com.example.bulgariantripadvisor;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}