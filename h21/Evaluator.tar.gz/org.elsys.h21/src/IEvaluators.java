
public class IEvaluators implements IEvaluator {

	private double sum =0.0;
	
	public void add (double d){
		
	}
	public double evaluate(){
		return sum;
	}
}
