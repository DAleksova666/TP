import java.util.ArrayList;


public class DirectEvaluatorFactory implements IEvaluator{
	private double sum =0.0 , pow = 0.0 , powr = 1 , powers = 1;
	private int c = 0;
	private double fib1 = 0, fib2 = 1 , cont;
	ArrayList<Double> param = new ArrayList<Double>();
	
	
	DirectEvaluatorFactory(int c){
		this.c = c;
	}

	DirectEvaluatorFactory(int c, int power){
		this.c = 3;
		this.powr = power;
	}
	
	
	public void add (double d){
			param.add(d);
	}
	public double evaluate(){
		
		if (c == 1){
			for (int i =0 ;i<param.size();i++){
				sum += param.get(i);
			}
		}
		if(c == 2){
			for (int i =0 ;i<param.size();i++){
				pow = param.get(i) * param.get(i);
				sum += pow;
			}
		}
		if (c == 3){
			for (int i = 0 ; i<param.size();i++){
				powers=1;
				for (int j = 0 ; j < powr ;j++){
					powers = powers * param.get(i);
				}
				sum+=powers;
			}
		}
		if (c == 4){
			for (int i =0 ;i<param.size();i++){
				sum += param.get(i);
			}
			while (fib2 < sum){
				cont = fib2;
				fib2 += fib1;
				fib1 = cont;
			}
			if (fib2 - sum < sum - fib1){
				return fib2;
			} else {
				return fib1;
			}
		}
		
		return sum;
	}
	
}
