
public interface IEvaluator {
	
	void add (double d);
	double evaluate();
}
