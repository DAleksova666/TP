
public class AbsoluteEvaluatorFactorys implements IEvaluatorFactory{
	public IEvaluator createSumEvaluator() {
		return new AbsoluteEvaluatorFactory(1);
	}
	public IEvaluator createPowerOnEvaluator() {
		return new AbsoluteEvaluatorFactory(2);
	}
	public IEvaluator createPowerOnEvaluator(int power) {
		return new AbsoluteEvaluatorFactory(3,power);
	}
	public IEvaluator createFibonaciEvaluator() {
		return new AbsoluteEvaluatorFactory(4);
	}
}

