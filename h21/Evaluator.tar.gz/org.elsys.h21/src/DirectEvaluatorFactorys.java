
public class DirectEvaluatorFactorys implements IEvaluatorFactory {

	public IEvaluator createSumEvaluator() {
		return new DirectEvaluatorFactory(1);
	}
	public IEvaluator createPowerOnEvaluator() {
		return new DirectEvaluatorFactory(2);
	}
	public IEvaluator createPowerOnEvaluator(int power) {
		return new DirectEvaluatorFactory(3,power);
	}
	public IEvaluator createFibonaciEvaluator() {
		return new DirectEvaluatorFactory(4);
	}
}
