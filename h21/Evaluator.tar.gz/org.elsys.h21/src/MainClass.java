


public class MainClass {

	public static void main(String[] args) {
		AbsoluteEvaluatorFactorys fact = new AbsoluteEvaluatorFactorys();
		IEvaluator eval = fact.createSumEvaluator();
		eval.add(2);
		eval.add(3);
		eval.add(4);
		System.out.println(eval.evaluate());
		
	
		AbsoluteEvaluatorFactorys fact2 = new AbsoluteEvaluatorFactorys();
		IEvaluator eval2 = fact2.createPowerOnEvaluator();
		eval2.add(2);
		eval2.add(3);
		eval2.add(4);
		System.out.println(eval2.evaluate());
		
		AbsoluteEvaluatorFactorys fact3 = new AbsoluteEvaluatorFactorys();
		IEvaluator eval3 = fact3.createPowerOnEvaluator(3);
		eval3.add(1);
		eval3.add(2);
		eval3.add(1);
		System.out.println(eval3.evaluate());
		
		AbsoluteEvaluatorFactorys fact4 = new AbsoluteEvaluatorFactorys();
		IEvaluator eval4 = fact4.createFibonaciEvaluator();
		eval4.add(100);
		eval4.add(30);
		eval4.add(1);
		System.out.println(eval4.evaluate());
		
	}

}
